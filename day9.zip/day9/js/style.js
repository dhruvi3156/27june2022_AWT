function focus(){
	document.getElementById('img4').src="../img/img2.jpg";
}